﻿using Microsoft.Crm.UnifiedServiceDesk.Dynamics;
using Microsoft.Uii.Desktop.Cti.Core;
using Microsoft.USD.ComponentLibrary.Adapters.Parature;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Microsoft.USD.ComponentLibrary
{
    /// <summary>
    /// Interaction logic for ArticleDisplay.xaml
    /// </summary>
    public partial class ArticleDisplay : DynamicsBaseHostedControl
    {
        public ArticleDisplay()
        {
            InitializeComponent();
        }

        /// <summary>
        /// UII Constructor 
        /// </summary>
        /// <param name="appID">ID of the application</param>
        /// <param name="appName">Name of the application</param>
        /// <param name="initString">Initializing XML for the application</param>
        public ArticleDisplay(Guid appID, string appName, string initString)
            : base(appID, appName, initString)
        {
            InitializeComponent();
        }

        protected override void DesktopReady()
        {
            base.DesktopReady();

            PopulateToolbars(ProgrammableToolbarTray);
        }

        System.Threading.Timer delayShowArticle;
        protected override void DoAction(Uii.Csr.RequestActionEventArgs args)
        {
            if (args.Action.Equals("ShowArticle", StringComparison.InvariantCultureIgnoreCase))
            {
                webbrowser.Navigate("about:blank");

                //The DoEvents code is commented because on some machines, the webbrowser.Handle would never be set, and the window would be held up for the full 30 seconds.
                //This would cause a ShowTab action to delay, waiting 30 seconds to focus on the article's hosted control (on some machines)
                //DateTime endTime = DateTime.Now + TimeSpan.FromSeconds(30);
                //while (webbrowser.Handle == IntPtr.Zero && DateTime.Now < endTime)
                //    System.Windows.Forms.Application.DoEvents();

                List<KeyValuePair<string, string>> parameters = Utility.SplitLines(args.Data, CurrentContext, localSession);
                string articleid = Utility.GetAndRemoveParameter(parameters, "articleid");
                string url = Utility.GetAndRemoveParameter(parameters, "url");
                string title = Utility.GetAndRemoveParameter(parameters, "title");
                string AcctID = Utility.GetAndRemoveParameter(parameters, "AcctID");
                string DeptID = Utility.GetAndRemoveParameter(parameters, "DeptID");
                string APIToken = Utility.GetAndRemoveParameter(parameters, "APIToken");
                string styleurl = Utility.GetAndRemoveParameter(parameters, "styleurl");
                string styletag = String.Empty;
                if (!String.IsNullOrEmpty(styleurl))
                {
                    styletag = String.Format("<link rel=\"stylesheet\" type=\"text/css\" href=\"{0}\">", Utility.EnsureQualifiedUrl(styleurl));
                }
                string APIDomain = Utility.GetAndRemoveParameter(parameters, "APIDomain");
                if (String.IsNullOrEmpty(APIDomain))
                    APIDomain = "https://demo.parature.com";
                try
                {
                    if (!String.IsNullOrEmpty(url))
                    {
                        // KB article that is just a straight URL
                        delayShowArticle = new System.Threading.Timer(new System.Threading.TimerCallback(ShowArticleUrlDelay), url, TimeSpan.FromMilliseconds(100), TimeSpan.Zero);

                        List<LookupRequestItem> lri = new List<LookupRequestItem>();
                        lri.Add(new LookupRequestItem("externallink",url));
                        lri.Add(new LookupRequestItem("articleid", "0"));
                        lri.Add(new LookupRequestItem("title", title));
                        lri.Add(new LookupRequestItem("text", ""));
                        ((DynamicsCustomerRecord)localSession.Customer.DesktopCustomer).MergeReplacementParameter(this.ApplicationName, lri, true);
                    }
                    else
                    {
                        // If required by the server, set the credentials.
                        ParaCredentials creds = new ParaCredentials(APIToken, APIDomain, Paraenums.ApiVersion.v1, int.Parse(AcctID), int.Parse(DeptID), false);
                        var article = ApiHandler.Article.ArticleGetDetails(long.Parse(articleid), creds);

                        if (!article.ApiCallResponse.HasException && article.Published)
                        {
                            string html = String.Format("<html><head>{0}</head><body><H2>{1}</H2><p>{2}</body></html>", styletag, article.Question, article.Answer);
                            delayShowArticle = new System.Threading.Timer(new System.Threading.TimerCallback(ShowArticleDelay), html, TimeSpan.FromMilliseconds(100), TimeSpan.Zero);

                            List<LookupRequestItem> lri = new List<LookupRequestItem>();
                            lri.Add(new LookupRequestItem("externallink",
                                String.Format("http://{0}.parature.com/link/portal/{1}/{2}/Article/{3}", APIDomain, AcctID, DeptID, articleid)));
                            lri.Add(new LookupRequestItem("articleid", articleid));
                            lri.Add(new LookupRequestItem("title", article.Question));
                            lri.Add(new LookupRequestItem("text", article.Answer));
                            ((DynamicsCustomerRecord)localSession.Customer.DesktopCustomer).MergeReplacementParameter(this.ApplicationName, lri, true);
                        }
                        else
                        {
                            throw new Exception(article.ApiCallResponse.ExceptionDetails);
                        }
                    }
                }
                finally
                {
                }
            }
            base.DoAction(args);
        }

        void ShowArticleDelay(object obj)
        {
            if (delayShowArticle != null)
            {
                delayShowArticle.Dispose();
                delayShowArticle = null;
            }
            Dispatcher.Invoke(() =>
            {
                HideScriptErrors(webbrowser, true);
                webbrowser.NavigateToString(obj as string);
            });
        }
        void ShowArticleUrlDelay(object obj)
        {
            if (delayShowArticle != null)
            {
                delayShowArticle.Dispose();
                delayShowArticle = null;
            }
            Dispatcher.Invoke(() =>
            {
                HideScriptErrors(webbrowser, true);
                webbrowser.Navigate(obj as string);
            });
        }

        private void HideScriptErrors(WebBrowser webBrowser, bool Hide)
        {
            FieldInfo fiComWebBrowser = typeof(System.Windows.Controls.WebBrowser).GetField("_axIWebBrowser2", BindingFlags.Instance | BindingFlags.NonPublic);
            if (fiComWebBrowser == null)
                return;
            object objComWebBrowser = fiComWebBrowser.GetValue(webBrowser);
            if (objComWebBrowser == null)
                return;
            objComWebBrowser.GetType().InvokeMember("Silent", BindingFlags.SetProperty, null, objComWebBrowser, new object[] { Hide });
        }

    }
}
