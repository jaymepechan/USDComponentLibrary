﻿using Microsoft.Crm.UnifiedServiceDesk.CommonUtility;
using Microsoft.Crm.UnifiedServiceDesk.Dynamics;
using Microsoft.USD.ComponentLibrary.Adapters.Parature;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Microsoft.USD.ComponentLibrary
{
    /// <summary>
    /// Interaction logic for ArticleList.xaml
    /// </summary>
    public partial class ArticleList : DynamicsBaseHostedControl
    {
        WebCallbackHandler webcallback ;
        private TraceLogger LogWriter = null;

        public ArticleList()
        {
            InitializeComponent();
            LogWriter = new TraceLogger();
        }

        /// <summary>
        /// UII Constructor 
        /// </summary>
        /// <param name="appID">ID of the application</param>
        /// <param name="appName">Name of the application</param>
        /// <param name="initString">Initializing XML for the application</param>
        public ArticleList(Guid appID, string appName, string initString)
            : base(appID, appName, initString)
        {
            InitializeComponent();
            LogWriter = new TraceLogger();
        }

        protected override void DesktopReady()
        {
            base.DesktopReady();

            PopulateToolbars(ProgrammableToolbarTray);
            webcallback = new WebCallbackHandler(this);
            webbrowser.ObjectForScripting = webcallback;
        }

        string AcctID;
        string pageSize;
        string pageNumber;
        string folderName;
        string folderID;
        string drafts;
        string DeptID;
        string APIToken;
        string styleurl;
        string APIDomain;
        protected override void DoAction(Uii.Csr.RequestActionEventArgs args)
        {
            if (args.Action.Equals("Load", StringComparison.InvariantCultureIgnoreCase))
            {
                List<KeyValuePair<string, string>> parameters = Utility.SplitLines(args.Data, CurrentContext, localSession);
                AcctID = Utility.GetAndRemoveParameter(parameters, "AcctID");
                pageSize = Utility.GetAndRemoveParameter(parameters, "pageSize");
                folderName = Utility.GetAndRemoveParameter(parameters, "folderName");
                folderID = Utility.GetAndRemoveParameter(parameters, "folderID");
                drafts = Utility.GetAndRemoveParameter(parameters, "drafts");
                DeptID = Utility.GetAndRemoveParameter(parameters, "DeptID");
                APIToken = Utility.GetAndRemoveParameter(parameters, "APIToken");
                styleurl = Utility.GetAndRemoveParameter(parameters, "style");
                APIDomain = Utility.GetAndRemoveParameter(parameters, "APIDomain");
                if (String.IsNullOrEmpty(APIDomain))
                    APIDomain = "https://demo.parature.com";
                webbrowser.Navigate("about:blank");
            }
            else if (args.Action.Equals("Search", StringComparison.InvariantCultureIgnoreCase))
            {
                webbrowser.Navigate("about:blank");
                List<KeyValuePair<string, string>> parameters = Utility.SplitLines(args.Data, CurrentContext, localSession);
                string searchString = Utility.GetAndRemoveParameter(parameters, "searchString");
                string _AcctID = Utility.GetAndRemoveParameter(parameters, "AcctID");
                string _pageSize = Utility.GetAndRemoveParameter(parameters, "pageSize");
                string _pageNumber = Utility.GetAndRemoveParameter(parameters, "pageNumber");
                string _folderName = Utility.GetAndRemoveParameter(parameters, "folderName");
                string _folderID = Utility.GetAndRemoveParameter(parameters, "folderID");
                string _drafts = Utility.GetAndRemoveParameter(parameters, "drafts");
                string _DeptID = Utility.GetAndRemoveParameter(parameters, "DeptID");
                string _APIToken = Utility.GetAndRemoveParameter(parameters, "APIToken");
                string _styleurl = Utility.GetAndRemoveParameter(parameters, "style");
                string _APIDomain = Utility.GetAndRemoveParameter(parameters, "APIDomain");

                SearchBox.Text = searchString;
                try
                {
                    // If required by the server, set the credentials.
                    ParaCredentials creds = new ParaCredentials(
                        !String.IsNullOrEmpty(_APIToken) ? _APIToken : APIToken,
                        !String.IsNullOrEmpty(_APIDomain) ? _APIDomain : APIDomain, Paraenums.ApiVersion.v1, 
                        !String.IsNullOrEmpty(_AcctID) ? int.Parse(_AcctID) : int.Parse(AcctID), 
                        !String.IsNullOrEmpty(_DeptID) ? int.Parse(_DeptID) : int.Parse(DeptID), false);
                    Search(searchString, creds, !String.IsNullOrEmpty(_styleurl) ? _styleurl : styleurl);
                }
                finally
                {
                }
            }
            base.DoAction(args);
        }

        System.Threading.Timer delayShowHTML;
        void Search(string searchString, ParaCredentials creds, string style)
        {
            string styletag = String.Empty;
            if (!String.IsNullOrEmpty(style))
            {
                styletag = String.Format("<link rel=\"stylesheet\" type=\"text/css\" href=\"{0}\">", Utility.EnsureQualifiedUrl(style));
            }

            //Search the content
            var searchQuery = new ModuleQuery.ArticleQuery();
            bool dTemp;
            if (!bool.TryParse(drafts, out dTemp)) searchQuery.AddStaticFieldFilter(ModuleQuery.ArticleQuery.ArticleStaticFields.Published, Paraenums.QueryCriteria.Equal, true);
            searchQuery.AddCustomFilter("_keywords_=" + searchString);
            try
            {
                searchQuery.PageSize = int.Parse(pageSize);
            }
            catch (Exception e)
            {
                //Default to 100
                searchQuery.PageSize = 100;
            }
            try
            {
                searchQuery.PageNumber = int.Parse(pageNumber);
            }
            catch (Exception e)
            {
                //Default to page 1
                searchQuery.PageNumber = 1;
            }
            var searchAnswer = ApiHandler.Article.ArticlesGetList(creds, searchQuery);

            if (searchAnswer.ApiCallResponse.HasException)
            {
                throw new Exception(searchAnswer.ApiCallResponse.ExceptionDetails);
            }
            else
            {
                StringBuilder articleMarkup = new StringBuilder();
                if (searchAnswer.Articles.Count == 0)
                {
                    articleMarkup.Append("<div class=\"searchResult\">No results were found.</div>");
                }
                foreach (ParaObjects.Article article in searchAnswer.Articles)
                {
                    articleMarkup.Append(String.Format("<div class=\"searchResult\"><div class=\"articleTitle\"><a class=\"articleLink\" onclick=\"window.external.ArticleChosen('{2}')\" target=\"_blank\" >{0}</a></div><div class=\"articlePreview\">{1}</div></div>",
                        PreviewQuestion(article), PreviewAnswer(article), article.Articleid));
                }
                string html = String.Format("<html><head>{0}</head><body><p>{1}</p></body></html>", styletag, articleMarkup.ToString());
                delayShowHTML = new System.Threading.Timer(new System.Threading.TimerCallback(ShowHTMLDelay), html, TimeSpan.FromMilliseconds(100), TimeSpan.Zero);
            }
        }
        void ShowHTMLDelay(object obj)
        {
            if (delayShowHTML != null)
            {
                delayShowHTML.Dispose();
                delayShowHTML = null;
            }
            Dispatcher.Invoke(() =>
            {
                webbrowser.NavigateToString(obj as string);
            });
        }

        private static string PreviewQuestion(ParaObjects.Article article)
        {
            return article.Question.Trim();
        }

        private static string PreviewAnswer(ParaObjects.Article article)
        {
            var decoded = HttpUtility.HtmlDecode(StripHTML(article.Answer.Trim()));
            return decoded.Substring(0, Math.Min(255, decoded.Length));
        }

        private static string StripHTML(string HTMLText)
        {
            Regex reg = new Regex("<[^>]+>", RegexOptions.IgnoreCase);
            return reg.Replace(HTMLText, "");
        }


        [ComVisible(true)]
        public class WebCallbackHandler
        {
            ArticleList _parent;
            public WebCallbackHandler(ArticleList parent)
            {
                _parent = parent;
            }

            public void ArticleChosen(String articleId)
            {
                _parent.FireEvent("ArticleChosen", new Dictionary<string, string>() { { "questionid", articleId } });
            }
        }

        private void DoSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // If required by the server, set the credentials.
                //Paraenums.ServerFarm farm;
                //Paraenums.ServerFarm.TryParse(APIDomain, true, out farm);
                ParaCredentials creds = new ParaCredentials(
                    APIToken,
                    APIDomain, Paraenums.ApiVersion.v1,
                    int.Parse(AcctID),
                    int.Parse(DeptID), false);
                Search(SearchBox.Text, creds, styleurl);
            }
            catch (Exception ex)
            {
                LogWriter.Log(ex);
            }
            finally
            {
            }
        }

        private void SearchBox_OnPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                DoSearch_Click(sender, e);
            }
        }
    }   
}
